cd 7segment
make
make install
cd ..
cd btnswitch 
make
make install
cd ..
cd led
make
make install
