mknod /dev/7segment c 248 0
mknod /dev/btnswitch c 247 0
mknod /dev/led c 246 0
